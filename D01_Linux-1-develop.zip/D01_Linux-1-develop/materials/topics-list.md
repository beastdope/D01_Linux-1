Hello, student of School21!😉

To make it easier for you to navigate the material, we have prepared a list of topics that you will learn in this project.

We will study:

- using command line;
- configuring OS Linux;
- superuser rights;
- installing apps via `apt`;
- using utils in terminal (top/htop/df/du/ncdu).

Now, knowing what awaits you in this project, you can slowly begin to study the topics listed above.😇
